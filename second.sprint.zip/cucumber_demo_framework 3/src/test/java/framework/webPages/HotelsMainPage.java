package framework.webPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import stepdefinition.SharedSD;

import java.util.ArrayList;
import java.util.List;

import static stepdefinition.SharedSD.getDriver;

public class HotelsMainPage extends BasePage {

    private String origin = "New York City";
    private String destination = "Orlando";
    private String checkInMonth = "April";
    private String checkInDay = "13";
    private String checkOutMonth = "April";
    private String checkOutDay = "17";

    private By packagesAndFlightButton = By.xpath("//nav[@class='header-secondary-nav']//li[2]");
    private By flightAndHotelButton = By.xpath("//button[@id='tab-package-tab-hp']");
    private By originInputField = By.xpath("//input[@id='package-origin-hp-package']");
    private By originAndDestinationResults = By.xpath("//div[@class='autocomplete-dropdown']//ul[@class='results']//li[@class='results-item']//a/span[@class='text']");
    private By destinationInputField =By.xpath("//input[@id='package-destination-hp-package']");

    private By checkInDatesDropdown = By.xpath("//div[@id='package-departing-wrapper-hp-package']//div[@class='datepicker-dropdown']//td[@class='datepicker-day-number notranslate']");
    private By checkOutDatesDropdown = By.xpath("//div[@id='package-returning-wrapper-hp-package']//div[@class='datepicker-dropdown']//td[@class='datepicker-day-number notranslate']");

    private By checkInBoxLocator = By.xpath("//input[@id='package-departing-hp-package']");
    private By checkOutBoxLocator = By.xpath("//input[@id='package-returning-hp-package']");

    private By searchButton = By.xpath("//button[@id='search-button-hp-package']");

    String starSelectorLocator = "//input[@id='star";

    private By resultsStarLocator = By.xpath("//div[@id='resultsContainer']//section//article//div[@class='flex-link-wrap ']//div[@class='flex-area-primary']//ul[@class='hotel-info']//li[@class='starRating secondary']");

    private By moreNeighborhoodButton = By.xpath("//div[@id='neighborhoodContainer']//fieldset[@class='filterContainer']//details[@class='filterDetails']//a//span[@class='more']");
    private By orlandoAirportSelector = By.xpath("//span[contains(text(),'MCO-Orlando Intl.')]");

    private By resultsDistanceFromAirportLocator = By.xpath("//div[@id='resultsContainer']//section//article//div//div[@class='flex-link-wrap ']//div//div[@class='flex-area-primary']//ul[@class='hotel-info']//li[@class='distance secondary tabAccess']");

    public void clickOnFlightAndHotelButton() {
        clickOn(flightAndHotelButton);
    }

    public void clickOnPackagesAndFlightButton() {
        clickOn(packagesAndFlightButton);
    }

    public void selectOriginOrDestination(String nameOfTheCity) {
        List<WebElement> elements = SharedSD.getDriver().findElements(originAndDestinationResults);
        for (WebElement element : elements) {
            if (element.getText().contains(nameOfTheCity)) {
                element.click();
                break;
            }
        }
    }

    public void selectOrigin() {
        setValue(originInputField, origin);
        selectOriginOrDestination(origin);
    }

    public void selectDestination() {
        setValue(destinationInputField, destination);
        selectOriginOrDestination(destination);
    }

    public void clickOnTheBoxAndSelectDate(By checkBoxLocator, By datesDropdownLocator, String month, String day) {
        clickOn(checkBoxLocator);
        List<WebElement> dates = SharedSD.getDriver().findElements(datesDropdownLocator);
        for (WebElement date : dates) {
            if (date.getText().contains(month) && date.getText().contains(day)) {
                date.click();
                break;
            }
        }
    }

    public void setTheDates() {
        clickOnTheBoxAndSelectDate(checkInBoxLocator, checkInDatesDropdown, checkInMonth, checkInDay);
        clickOnTheBoxAndSelectDate(checkOutBoxLocator, checkOutDatesDropdown, checkOutMonth, checkOutDay);
    }

    public void clickOnSearchButton() {
        clickOn(searchButton);
    }

    public void selectPropertyClass(String stars) {
        clickOn(By.xpath(starSelectorLocator + stars + "']"));
    }

    public boolean verifyStarHotelsDisplayedCorrectly(String stars) {
        List<String> expectedListOfHotels = new ArrayList<>();
        List<String> actualListOfHotels = new ArrayList<>();
        List<WebElement> hotels = SharedSD.getDriver().findElements(resultsStarLocator);
        for (WebElement hotel : hotels) {
            expectedListOfHotels.add(hotel.getText());
            switch (stars) {
                case "5":
                    if (hotel.getText().contains(stars + ".0 " + "out of 5.0")) {
                        actualListOfHotels.add(hotel.getText());
                    }
                    break;
                case "4":
                case "3":
                    if (hotel.getText().contains(stars + ".")) {
                        actualListOfHotels.add(hotel.getText());
                    }
                    break;
            }
        }
        return expectedListOfHotels.equals(actualListOfHotels);
    }

    public void expandNeighborhoodAndSelectAirport() throws InterruptedException {
        SharedSD.getDriver().manage().window().maximize();
        JavascriptExecutor jse = (JavascriptExecutor)getDriver();
        jse.executeScript("window.scrollBy(0,750)", "");
        Thread.sleep(1000);
        clickOn(moreNeighborhoodButton);
        Thread.sleep(1000);
        clickOn(orlandoAirportSelector);
        Thread.sleep(10000);
    }

    public boolean verifyThatHotelAreWithin10milesFromArport() {
        List<Float> expectedListOfHotels = new ArrayList<>();
        List<Float> actualListOfHotels = new ArrayList<>();
        List<WebElement> hotels = SharedSD.getDriver().findElements(resultsDistanceFromAirportLocator);
        for (WebElement hotel : hotels) {
            String[] distanceInString = hotel.getText().split(" km");
            expectedListOfHotels.add(Float.parseFloat(distanceInString[0]));
            if (Float.parseFloat(distanceInString[0]) <= 16) {
                actualListOfHotels.add(Float.parseFloat(distanceInString[0]));
            }
        }
        return expectedListOfHotels.equals(actualListOfHotels);
    }


}
