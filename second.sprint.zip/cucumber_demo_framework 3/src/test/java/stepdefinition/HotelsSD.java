package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.webPages.HotelsMainPage;
import org.testng.Assert;

public class HotelsSD {

    HotelsMainPage hotelsMainPage = new HotelsMainPage();

    @Given("^I am on default locations search result screen$")
    public void goToDefaultSearchLocation() {
        hotelsMainPage.clickOnPackagesAndFlightButton();
        hotelsMainPage.clickOnFlightAndHotelButton();
        hotelsMainPage.selectOrigin();
        hotelsMainPage.selectDestination();
        hotelsMainPage.setTheDates();
        hotelsMainPage.clickOnSearchButton();
    }

    @When("^I select property class (.+)$")
    public void selectPropertyClass(String stars) throws InterruptedException {
        switch (stars) {
            case "5 stars":
                hotelsMainPage.selectPropertyClass("5");
                Thread.sleep(10000);
                break;
            case "4 stars" :
                hotelsMainPage.selectPropertyClass("4");
                Thread.sleep(10000);
                break;
            case "3 stars":
                hotelsMainPage.selectPropertyClass("3");
                Thread.sleep(10000);
                break;
        }
    }

    @Then("^I verify system displays only (.+) hotels on search result$")
    public void verifySystemDisplaysRequiredStarHotelsOnly(String stars) {
        switch (stars) {
            case "5 stars":
                Assert.assertTrue(hotelsMainPage.verifyStarHotelsDisplayedCorrectly("5"));
                break;
            case "4 stars" :
                Assert.assertTrue(hotelsMainPage.verifyStarHotelsDisplayedCorrectly("4"));
                break;
            case "3 stars":
                Assert.assertTrue(hotelsMainPage.verifyStarHotelsDisplayedCorrectly("3"));
                break;
        }
    }

    @Then("^I verify system displays all hotels within the airport$")
    public void verifySystemDisplaysHotelsWithin10milesFromAirport() throws InterruptedException {
        hotelsMainPage.expandNeighborhoodAndSelectAirport();
        Thread.sleep(2000);
        Assert.assertTrue(hotelsMainPage.verifyThatHotelAreWithin10milesFromArport());
    }
}
