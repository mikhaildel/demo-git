package framework.webPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import stepdefinition.SharedSD;

import java.text.SimpleDateFormat;
import java.util.*;

import static stepdefinition.SharedSD.getDriver;

public class DarkSkyMainPage extends BasePage {

    private By currentTemperatureLocator = By.xpath("//span[@class='summary swap']");
    private By currentTemperatureTimeline = By.xpath("//div[@id='timeline']//div[@class='timeline']//div[@class='temps']/span/span");
    private By hoursNow = By.xpath("//div[@id='timeline']//div[@class='hours']//span[@class='hour first']/span");
    private By hoursTimeline = By.xpath("//div[@id='timeline']//div[@class='hours']//span[@class='hour']/span");
    private By expandDayTimeline = By.xpath("//a[1]//span[3]//span[1]");
    private By minTempDisplayed = By.xpath("//a[@class='day revealed']//span[@class='tempRange']//span[@class='minTemp']");
    private By minTempExpanded = By.xpath("//div[@class='dayDetails revealed']//div[@class='highLowTemp swip']//span[@class='highTemp swip']//span[@class='temp']");
    private By maxTempDisplayed = By.xpath("//a[@class='day revealed']//span[@class='tempRange']//span[@class='maxTemp']");
    private By maxTempExpanded = By.xpath("//div[@class='dayDetails revealed']//div[@class='highLowTemp swip']//span[@class='lowTemp swap']//span[@class='temp']");


    private byte increment = 2;

    public boolean isDarkSkyTitleDisplayed() {
        return getDriver().getTitle().contains("Dark Sky");
    }

    public boolean isNowDisplayed() {
        return getDriver().findElement(hoursNow).getText().equals("Now");
    }

    public boolean isHourTimelineDisplayedCorrectly() {
        boolean isCorrect = false;
        SimpleDateFormat format = new SimpleDateFormat("hh");
        Date date = new Date();
        byte currentHour = Byte.parseByte(format.format(date));
        ArrayList<Byte> hoursInByte = new ArrayList<>();
        hoursInByte.add(currentHour);
        List<WebElement> hours = getDriver().findElements(hoursTimeline);
        for (WebElement hour: hours) {
            switch (hour.getText().length()) {
                case 3: hoursInByte.add(Byte.parseByte(hour.getText().substring(0, 1))); break;
                case 4: hoursInByte.add(Byte.parseByte(hour.getText().substring(0, 2))); break;
            }
        }
        for (int i = 0; i < hoursInByte.size() - 1; i++) {
            if ((hoursInByte.get(i) == 11) || (hoursInByte.get(i) == 12)) {
              if (((hoursInByte.get(i + 1) + 12) - hoursInByte.get(i)) == increment) {
                 isCorrect = true;
              } else {
                  isCorrect = false;
                  break;
              }
          } else {
              if ((hoursInByte.get(i + 1) - hoursInByte.get(i)) == increment) {
                  isCorrect = true;
              } else {
                  isCorrect = false;
                  break;
              }
          }

        }
        return isCorrect;
    }

    public boolean isLowestAndHighestTempDisplayedCorrectly() throws InterruptedException {
        boolean isCorrect = false;
        JavascriptExecutor jse = (JavascriptExecutor)getDriver();
        jse.executeScript("window.scrollBy(0,650)", "");
        Thread.sleep(1000);
        getDriver().findElement(expandDayTimeline).click();
        Thread.sleep(2000);
        if (SharedSD.getDriver().findElement(minTempDisplayed).getText().equals(SharedSD.getDriver().findElement(minTempExpanded).getText()) &&
                SharedSD.getDriver().findElement(maxTempDisplayed).getText().equals(SharedSD.getDriver().findElement(maxTempExpanded).getText()))
        {
            isCorrect = true;
        }
        return isCorrect;
    }

    public int getCurrentTemperature() {
        String charsOfTheCurrentTemperatureString = getDriver().findElement(currentTemperatureLocator).getText();
        String currentTemperature = "";
        for (int i = 0; i < charsOfTheCurrentTemperatureString.length(); i++) {
            if (Character.isDigit(charsOfTheCurrentTemperatureString.charAt(i))) {
            currentTemperature = currentTemperature + charsOfTheCurrentTemperatureString.charAt(i);
            }
        }
        return Integer.parseInt(currentTemperature);
    }


    public boolean isCurrentTemperatureWithinTheTimeline() {

        ArrayList<Integer> numsOfTimeline = new ArrayList<>();
        List<WebElement> temperatures = getDriver().findElements(currentTemperatureTimeline);
        for (WebElement temperature : temperatures) {
            numsOfTimeline.add(Integer.parseInt(temperature.getText().substring(0, temperature.getText().length() - 1)));
        }

        int currentTemperature = getCurrentTemperature();
        Collections.sort(numsOfTimeline);
        if ((currentTemperature >= numsOfTimeline.get(0)) && (currentTemperature <= numsOfTimeline.get(numsOfTimeline.size() -1))) {
            return true;
        } else {
            return false;
        }

    }

}
