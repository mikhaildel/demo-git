package framework.webPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import stepdefinition.SharedSD;

import java.net.URL;

import static stepdefinition.SharedSD.getDriver;

public class DarkSkyApiPage extends BasePage {

    private By signUpButton = By.xpath("//a[@class='button filled']");
    private By emailField = By.xpath("//input[@class='full' and @name='email']");
    private By passwordField = By.xpath("//input[@class='full' and @name='password']");
    private By verifyPasswordField = By.xpath("//input[@class='full' and @name='confirmation']");
    private By registerButton = By.xpath("//button[@type='submit']");
    private String gmailURL = "https://gmail.com/";

    private By loginToApi = By.xpath("//div[@class='header-container']//nav[@class='nav']//ul[@class='links']//descendant::li[4]");
    private By logInButton = By.xpath("//button[@type='submit']");

    private By darkSkyAccountSettings = By.xpath("//a[contains(text(),'Account Settings')]");

    public String actualEmail = "";
    public String actualPassword = "";


    public void clickOnSignUpButton() {
        clickOn(signUpButton);
    }

    public void enterEmail(String enterEmail) {
        actualEmail = enterEmail;
        setValue(emailField, enterEmail);
    }

    public void enterPassword(String password) {
        actualPassword = password;
        setValue(passwordField, password);
    }

    public void enterVerifyPasswordField(String confirmation) {
        setValue(verifyPasswordField, confirmation);
    }

    public void clickOnRegisterButton() {
        clickOn(registerButton);
    }

    public void navigateToGmail() {
        SharedSD.getDriver().navigate().to(gmailURL);
    }

    public void loginToApi() throws InterruptedException {
        clickOn(loginToApi);
        Thread.sleep(2000);
        //Logging in to gmail with previously stored credentials
        enterEmail(actualEmail);
        enterPassword(actualPassword);
        clickOn(logInButton);
        Thread.sleep(2000);
        clickOn(darkSkyAccountSettings);
        SharedSD.getDriver().manage().window().maximize();
        JavascriptExecutor jse = (JavascriptExecutor)getDriver();
        jse.executeScript("window.scrollBy(0,820)", "");
    }
}
