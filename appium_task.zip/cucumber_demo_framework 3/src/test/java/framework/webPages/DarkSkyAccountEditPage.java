package framework.webPages;

import org.openqa.selenium.By;
import stepdefinition.SharedSD;

public class DarkSkyAccountEditPage extends BasePage {

    private By cardholdersNameLocator = By.xpath("//input[@name='cardholder_name']");
    private By cardNumberLocator = By.xpath("//input[@data-stripe='number']");
    private By monthDropdown = By.xpath("//select[@data-stripe='exp-month']");
    private By yearDropdown = By.xpath("//select[@data-stripe='exp-year']");
    private By cvcField = By.xpath("//input[@data-stripe='cvc']");
    private By addressLine1Field = By.xpath("//input[@data-stripe='address_line1']");
    private By cityField = By.xpath("//input[@data-stripe='address_city']");
    private By zipField = By.xpath("//input[@data-stripe='address_zip']");
    private By countryField = By.xpath("//input[@data-stripe='address_country']");

    private By addCardButton = By.xpath("//button[contains(text(),'Add Card')]");
    private By errorMessageLocator = By.xpath("//div[@class='error']");

    public void enterCardholdersName(String cardHoldersName) {
        setValue(cardholdersNameLocator, cardHoldersName);
    }

    public void enterCardNumber(String cardNumber) {
        setValue(cardNumberLocator, cardNumber);
    }

    public void enterMonth(String month) {
        selectFromDropdown(monthDropdown, month);
    }

    public void enterYear(String year) {
        selectFromDropdown(yearDropdown, year);
    }

    public void enterCvc(String cvc) {
        setValue(cvcField, cvc);
    }

    public void enterAddress(String address) {
        setValue(addressLine1Field, address);
    }

    public void enterCity(String city) {
        setValue(cityField, city);
    }

    public void enterZip(String zip) {
        setValue(zipField, zip);
    }

    public void enterCountry(String country) {
        setValue(countryField, country);
    }

    public void hitAddCardButton() {
        clickOn(addCardButton);
    }

    public boolean isErrorMessageDisplayed() {
        return SharedSD.getDriver().findElement(errorMessageLocator).getText().contains("Your card was declined.");
    }

}
