package framework.webPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepdefinition.SharedSD;

import java.util.ArrayList;
import java.util.List;

public class GmailPage extends BasePage {

    private By enterEmail = By.xpath("//input[@id='identifierId']");
    private By enterPassword = By.xpath("//input[@name='password']");
    private By hitNext1 = By.xpath("//div[@id='identifierNext']");
    private By hitNext2 = By.xpath("//div[@id='passwordNext']");

    private By confirmationEmailFromDarkSky = By.xpath("//*[@class='yW']/span");
    private By confirmationLink = By.partialLinkText("https://darksky.net/");

    public void enterEmail(String email) {
        setValue(enterEmail, email);
        clickOn(hitNext1);
    }

    public void enterPassword(String password) {
        setValue(enterPassword, password);
        clickOn(hitNext2);
    }

    public void clickOnConfirmationEmail() {
        List<WebElement> emails = SharedSD.getDriver().findElements(confirmationEmailFromDarkSky);
        for (WebElement email: emails) {
            if (email.getText().equals("Dark Sky Developer .")) {
                email.click();
            }
        }
    }

    public void clickOnConfirmationLink() {
        clickOn(confirmationLink);
    }

    public void closePopUpAndGoBackToDarkskyApi() {
        List<String> listOfWindows = new ArrayList<>(SharedSD.getDriver().getWindowHandles());
        SharedSD.getDriver().switchTo().window(listOfWindows.get(0));
        SharedSD.getDriver().close();
        SharedSD.getDriver().switchTo().window(listOfWindows.get(1));
    }

}
