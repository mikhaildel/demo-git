package framework.mobilePages;

import framework.MobileBasePage;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class MainMenu extends MobileBasePage {

    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Menu']")
    private MobileElement sidebarHeader;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Navigate']")
    private MobileElement navigate;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Account']")
    private MobileElement account;

    @AndroidFindBy(xpath = "//android.view.View[@content-desc='Tutorial']")
    private MobileElement tutorial;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='calendar Schedule ']")
    private MobileElement schedule;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='contacts Speakers ']")
    private MobileElement speakers;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='map Map ']")
    private MobileElement map;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='information circle About ']")
    private MobileElement about;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='log in Login ']")
    private MobileElement login;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='help Support ']")
    private MobileElement support;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='person add Signup ']")
    private MobileElement signUp;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='hammer Show Tutorial ']")
    private MobileElement showTutorial;



    public boolean isMenuPresent() {
        return isElementDisplayed(sidebarHeader);
    }

    public boolean isNavigateDisplayed() {
        return isElementDisplayed(navigate);
    }

    public boolean isAccountDisplayed() {
        return isElementDisplayed(account);
    }

    public boolean isTutorialDisplayed() {
        return isElementDisplayed(tutorial);
    }

    public boolean isScheduleEnabled() {
        return isElementEnabled(schedule);
    }
    public boolean isSpeakersEnabled() {
        return isElementEnabled(speakers);
    }
    public boolean isMapEnabled() {
        return isElementEnabled(map);
    }
    public boolean isAboutEnabled() {
        return isElementEnabled(about);
    }
    public boolean isLoginEnabled() {
        return isElementEnabled(login);
    }
    public boolean isSupportEnabled() {
        return isElementEnabled(support);
    }
    public boolean isSignUpEnabled() {
        return isElementEnabled(signUp);
    }
    public boolean isShowTutorialEnabled() {
        return isElementEnabled(showTutorial);
    }

}
