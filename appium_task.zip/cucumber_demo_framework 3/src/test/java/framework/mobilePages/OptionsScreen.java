package framework.mobilePages;

import framework.MobileBasePage;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class OptionsScreen extends MobileBasePage {

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Angular']")
    private MobileElement angularCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Communication']")
    private MobileElement communicationCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Design']")
    private MobileElement designCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Documentation']")
    private MobileElement documentationCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Food']")
    private MobileElement foodCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Ionic']")
    private MobileElement ionicCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Navigation']")
    private MobileElement navigationCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Services']")
    private MobileElement servicesCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Tooling']")
    private MobileElement toolingCheckBox;

    @AndroidFindBy(xpath = "//android.widget.CheckBox[@content-desc='Workshop']")
    private MobileElement workshopCheckBox;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Reset All Filters ']")
    private MobileElement resetAllFiltersButton;

    public void tapOnAnOption(String option) {
        switch (option) {
            case "Angular": tapOn(angularCheckBox); break;
        }
    }

    public void resetAllFilters() {
        tapOn(resetAllFiltersButton);
    }

    public boolean areAllBoxesChecked() {
        return (angularCheckBox.getAttribute("checked").equals("true") && communicationCheckBox.getAttribute("checked").equals("true") && designCheckBox.getAttribute("checked").equals("true") && documentationCheckBox.getAttribute("checked").equals("true") && foodCheckBox.getAttribute("checked").equals("true") && ionicCheckBox.getAttribute("checked").equals("true") && navigationCheckBox.getAttribute("checked").equals("true") && servicesCheckBox.getAttribute("checked").equals("true") && toolingCheckBox.getAttribute("checked").equals("true") && workshopCheckBox.getAttribute("checked").equals("true"));
    }

}
