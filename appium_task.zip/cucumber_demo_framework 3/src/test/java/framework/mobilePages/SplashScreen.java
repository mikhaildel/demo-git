package framework.mobilePages;

import framework.MobileBasePage;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SplashScreen extends MobileBasePage {

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc='CONTINUE arrow forward ']")
    private MobileElement continueButton;

    public void swipeThreeTimes() {
        swipeScreenHorizontally(3);
    }

    public boolean isContinueButtonDisplayed() {
        return isElementEnabled(continueButton);
    }

}
