package stepdefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.mobilePages.HomeScreen;
import framework.mobilePages.MainMenu;
import framework.mobilePages.OptionsScreen;
import framework.mobilePages.SplashScreen;
import gherkin.lexer.Th;
import org.testng.Assert;

public class MobileMenuSD {

    private MainMenu mainMenu = new MainMenu();
    private HomeScreen homeScreen = new HomeScreen();
    private SplashScreen splashScreen = new SplashScreen();
    private OptionsScreen optionsScreen = new OptionsScreen();

    @When("^I tap on skip button$")
    public void clickOnSkipButton() throws InterruptedException {
        Thread.sleep(5000);
        homeScreen.tapOnSkipButton();
    }

    @When("^I tap on menu button$")
    public void clickOnMenuButton() throws InterruptedException {
        Thread.sleep(3000);
        homeScreen.tapOnMainMenuButton();
    }

    @When("^I tap on menu button again$")
    public void clickOnMenuButtonAgain() throws InterruptedException {
        Thread.sleep(3000);
        homeScreen.tapOnMainMenuButton();
    }

    @When("^I tap on skip button one more time$")
    public void clickOnSkipButtonOneMoreTime() throws InterruptedException {
        Thread.sleep(5000);
        homeScreen.tapOnSkipButton();
    }

    @When("^I tap on skip button over again$")
    public void clickOnSkipButtonOverAgain() throws InterruptedException {
        Thread.sleep(5000);
        homeScreen.tapOnSkipButton();
    }

    @When("^I swipe the screen 3 times$")
    public void swipeScreenThreeTimes() throws InterruptedException {
        Thread.sleep(5000);
        splashScreen.swipeThreeTimes();
    }

    @And("^I click on filter button$")
    public void tapOnFilterButton() throws InterruptedException {
        homeScreen.tapOnOptionsButton();
        Thread.sleep(3000);
    }

    @And("^I disable (.+) option$")
    public void disableOption(String anyText) {
        optionsScreen.tapOnAnOption(anyText);
    }

    @And("^I click on All Reset Filter button$")
    public void clickOnAllResetButton() throws InterruptedException {
        optionsScreen.resetAllFilters();
        Thread.sleep(3000);
    }

    @Then("^I verify all the elements of sidebar menu are displayed$")
    public void verifyMenuItemsDisplayed() {
        Assert.assertTrue(mainMenu.isNavigateDisplayed());
        Assert.assertTrue(mainMenu.isAccountDisplayed());
        Assert.assertTrue(mainMenu.isTutorialDisplayed());
        Assert.assertTrue(mainMenu.isScheduleEnabled());
        Assert.assertTrue(mainMenu.isSpeakersEnabled());
        Assert.assertTrue(mainMenu.isMapEnabled());
        Assert.assertTrue(mainMenu.isLoginEnabled());
        Assert.assertTrue(mainMenu.isSignUpEnabled());
        Assert.assertTrue(mainMenu.isAboutEnabled());
        Assert.assertTrue(mainMenu.isSupportEnabled());
        Assert.assertTrue(mainMenu.isShowTutorialEnabled());
    }

    @Then("^I verify sidebar menu is displayed$")
    public void verifySidebarMenu() {
        Assert.assertTrue(mainMenu.isMenuPresent());
    }

    @Then("^I verify that continue button is displayed$")
    public void verifyContinueButtonDisplayed() {
        Assert.assertTrue(splashScreen.isContinueButtonDisplayed());
    }

    @Then("^I verify all options are enabled$")
    public void verifyAllOptionsEnabled() {
        Assert.assertTrue(optionsScreen.areAllBoxesChecked());
    }

}
