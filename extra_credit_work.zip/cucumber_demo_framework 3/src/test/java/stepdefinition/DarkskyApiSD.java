package stepdefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.webPages.DarkSkyAccountEditPage;
import framework.webPages.DarkSkyApiPage;
import framework.webPages.DarkSkyMainPage;
import framework.webPages.GmailPage;
import org.testng.Assert;

public class DarkskyApiSD {

    private DarkSkyMainPage homePage = new DarkSkyMainPage();
    private DarkSkyApiPage darkSkyApiPage = new DarkSkyApiPage();
    private GmailPage gmailPage = new GmailPage();
    private DarkSkyAccountEditPage darkSkyAccountEditPage = new DarkSkyAccountEditPage();

    @Given("^I am on DarkSky homepage$")
    public void iAmOnDarkskyHomePage() {
        Assert.assertTrue(homePage.isDarkSkyTitleDisplayed());
    }

    @Then("^I click on Darksky API$")
    public void iClickOnDarkskyApiButton() {
        homePage.clickOnDarkskyApiButton();
    }

    @Then("^I click on Sign Up button$")
    public void iClickOnSignUpButton() {
        darkSkyApiPage.clickOnSignUpButton();
    }

    @Then("^I enter (.+) into (email|password|confirmation) field on sign up screen$")
    public void enterDataIntoTextFields(String anyText, String textFields) {

        switch (textFields) {
            case "email":
                darkSkyApiPage.enterEmail(anyText);
                break;
            case "password":
                darkSkyApiPage.enterPassword(anyText);
                break;
            case "confirmation":
                darkSkyApiPage.enterVerifyPasswordField(anyText);
                break;
        }
    }

    @Then("^I click on a register button$")
    public void iClickOnRegisterButton() throws InterruptedException {
        darkSkyApiPage.clickOnRegisterButton();
        //This 15 seconds implemented here so the confirmation email could reach a mailbox
        Thread.sleep(15000);
    }

    @Then("^I go to gmail.com and I verify my Darksky API account$")
    public void verifyMyDarkskyApiAccount() throws InterruptedException {
        darkSkyApiPage.navigateToGmail();
        Thread.sleep(2000);
        gmailPage.enterEmail(darkSkyApiPage.actualEmail);
        Thread.sleep(2000);
        gmailPage.enterPassword(darkSkyApiPage.actualPassword);
        Thread.sleep(2000);
        gmailPage.clickOnConfirmationEmail();
        Thread.sleep(2000);
        gmailPage.clickOnConfirmationLink();
        Thread.sleep(2000);
        gmailPage.closePopUpAndGoBackToDarkskyApi();
        Thread.sleep(2000);
    }

    @Then("^I login to API and go to account settings$")
    public void iGoToDarkskyApiSettings() throws InterruptedException {
        darkSkyApiPage.loginToApi();
        Thread.sleep(2000);
    }

    @When("^I enter (.*) into (CardholdersName|CardNumber|MonthDropdown|YearDropdown|CVC|AddressLine1|City|Zip|Country) field$")
    public void enterDataIntoAddCardFields(String anyText, String textFields) {

        switch (textFields) {
            case "CardholdersName":
                darkSkyAccountEditPage.enterCardholdersName(anyText);
                break;
            case "CardNumber":
                darkSkyAccountEditPage.enterCardNumber(anyText);
                break;
            case "MonthDropdown":
                darkSkyAccountEditPage.enterMonth(anyText);
                break;
            case "YearDropdown":
                darkSkyAccountEditPage.enterYear(anyText);
                break;
            case "CVC":
                darkSkyAccountEditPage.enterCvc(anyText);
                break;
            case "AddressLine1":
                darkSkyAccountEditPage.enterAddress(anyText);
                break;
            case "City":
                darkSkyAccountEditPage.enterCity(anyText);
                break;
            case "Zip":
                darkSkyAccountEditPage.enterZip(anyText);
                break;
            case "Country":
                darkSkyAccountEditPage.enterCountry(anyText);
                break;
        }
    }

    @And("^I hit AddCard button$")
    public void hitAddCardButton() throws InterruptedException {
        darkSkyAccountEditPage.hitAddCardButton();
        Thread.sleep(2000);
    }

    @Then("^I verify that I that an error message is displayed$")
    public void verifyInvalidCard() {
        Assert.assertTrue(darkSkyAccountEditPage.isErrorMessageDisplayed());
    }

}
